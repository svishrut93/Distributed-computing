package com.java.service;

public interface IPolicyService {

	public String getPolicy();
	
	public Boolean setPolicy(String policy);
	
}
